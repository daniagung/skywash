<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?php echo $page_title; ?></title>
	<?php $this->load->view('invest/script'); ?>
</head>
