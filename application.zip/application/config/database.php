<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$active_group = 'wl';
$active_record = TRUE;

$db['wl']['hostname'] = 'localhost';
$db['wl']['username'] = 'waroenk2_wl_app2';
$db['wl']['password'] = 'adaada22';
$db['wl']['database'] = 'waroenk2_wl_app2';
$db['wl']['dbdriver'] = 'mysql';
$db['wl']['dbprefix'] = '';
$db['wl']['pconnect'] = TRUE;
$db['wl']['db_debug'] = TRUE;
$db['wl']['cache_on'] = FALSE;
$db['wl']['cachedir'] = '';
$db['wl']['char_set'] = 'utf8';
$db['wl']['dbcollat'] = 'utf8_general_ci';

/* End of file database.php */
/* Location: ./application/config/database.php */