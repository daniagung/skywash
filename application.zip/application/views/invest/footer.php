 <div class="art-footer">
	<div class="art-footer-t"></div>
	<div class="art-footer-b"></div>
	<div class="art-footer-body">
		<a href="#" class="art-rss-tag-icon" title="RSS"></a>
		<div class="art-footer-text">
			<p><a href="#">Link1</a> | <a href="#">Link2</a> | <a href="#">Link3</a></p><p>Copyright © 2013. All Rights Reserved.</p>
		</div>
		<div class="cleared"></div>
	</div>
</div>
<div class="cleared"></div>