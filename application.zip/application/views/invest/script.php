<link href="<?php echo base_url();?>themes/img/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link rel="stylesheet" href="<?php echo base_url(); ?>themes/css/style.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo base_url(); ?>themes/css/style.tambahan.css" type="text/css" media="screen" />
<!--[if IE 6]><link rel="stylesheet" href="<?php echo base_url(); ?>themes/css/style.ie6.css" type="text/css" media="screen" /><![endif]-->
<!--[if IE 7]><link rel="stylesheet" href="<?php echo base_url(); ?>themes/css/style.ie7.css" type="text/css" media="screen" /><![endif]-->
<script type="text/javascript" src="<?php echo base_url(); ?>themes/js/script.js"></script>