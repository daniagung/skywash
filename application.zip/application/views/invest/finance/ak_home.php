<div class="art-content-layout">
	<div class="art-content-layout-row">
		<div class="art-layout-cell art-content">
			<div class="art-post">
				<div class="art-post-body">
					<div class="art-post-inner art-article">
				<!-- MULAI KONTEN -->
						<div class="art-postcontent">
							
							<fieldset>
								<legend>Menu Keuangan</legend>
								<table class="home-menu" width="100%">
									<tr>
										<td>
											<img src="<?php echo base_url(); ?>themes/img/ak-menu/1-jurnal.png" title="Jurnal"/><br/>
											<a class="tombol" href="<?php echo base_url(); ?>index.php/<?php echo $this->mza_secureurl->setSecureUrl_encode("invest_finance","jurnal",array("NO")); ?>">Jurnal</a>
										</td>
										<td>
											<img src="<?php echo base_url(); ?>themes/img/ak-menu/2-buku.png" title="Buku Besar"/><br/>
											<a class="tombol" href="<?php echo base_url(); ?>index.php/<?php echo $this->mza_secureurl->setSecureUrl_encode("invest_finance",'buku',array('NO'));?>">Buku Besar</a>
										</td>
										<td>
											<img src="<?php echo base_url(); ?>themes/img/ak-menu/3-nsaldo.png" title="Neraca Saldo"/><br/>
											<a class="tombol" href="<?php echo base_url(); ?>index.php/<?php echo $this->mza_secureurl->setSecureUrl_encode("invest_finance",'neracaSaldo',array('NO'));?>">Neraca Saldo</a>
										</td>
									</tr>
									<tr>
										<td colspan="3">&nbsp;</td>
									</tr>
									<tr>
										<td>
											<img src="<?php echo base_url(); ?>themes/img/ak-menu/4-labarugi.png" title="Laporan Laba / Rugi"/><br/>
											<a class="tombol" href="<?php echo base_url(); ?>index.php/<?php echo $this->mza_secureurl->setSecureUrl_encode("invest_finance",'labarugi',array('NO'));?>">Laba / Rugi</a>
										</td>
										<td>
											<img src="<?php echo base_url(); ?>themes/img/ak-menu/5-neraca.png" title="Neraca"/><br/>
											<a class="tombol" href="<?php echo base_url(); ?>index.php/<?php echo $this->mza_secureurl->setSecureUrl_encode("invest_finance",'neraca',array('NO'));?>">Neraca</a>
										</td>
										<td>&nbsp;</td>
									</tr>
								</table>
							</fieldset>
							
							<div class="cleared"></div>
						</div>
				<!-- AKHIR KONTEN -->
						<div class="cleared"></div>
					</div>
					<div class="cleared"></div>
				</div>
			</div>
			<div class="cleared"></div>
		</div>
	</div>
</div>
<div class="cleared"></div>