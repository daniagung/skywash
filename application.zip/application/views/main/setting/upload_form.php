<div style="width:50%;text-align:center;padding:35px 10px 15px 10px;">
	<a href="<?php echo base_url(); ?>index.php/<?php echo $this->mza_secureurl->setSecureUrl_encode( 'upload','upload',array($this->session->userdata('id')) ); ?>" class="tombol" style="font-size:18px;">UPLOAD DATA</a>
</div>